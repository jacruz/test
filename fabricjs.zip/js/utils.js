//////////////////////////////
/////TAMAÑOS Y POSICIONES/////
//////////////////////////////

var w = window,
	d = document,
	e = d.documentElement,
	g = d.getElementsByTagName('body')[0],
	x = w.innerWidth || e.clientWidth || g.clientWidth,
	y = w.innerHeight|| e.clientHeight|| g.clientHeight;


var iniX = 230;
var iniY = 407;
var finX = 0;
var finY = 0;

function resizeCanvas() {

	var percentToIncrease = 0;
	var percentFinal = 100;
	var error = 1;//posible error al realizar operaciones... acepta un error de 1px
	
	//Intenta incrementar por X
	var difX = x - iniX;
	percentToIncrease = difX*100/iniX;
	finX = iniX + (iniX*percentToIncrease/100);
	finY = iniY + (iniY*percentToIncrease/100);
	
	//Si algún valor es mayor al de la pantalla entonces debe incrementar por Y
	if(finX > (x+error) || finY > (y+error)){
		var difY = y - iniY;
		percentToIncrease = difY*100/iniY;
		finX = iniX + (iniX*percentToIncrease/100);
		finY = iniY + (iniY*percentToIncrease/100);
	}
	
	//hasta aqui sería pantalla completa, se disminuye si aplica 
	finX = finX*percentFinal/100;
	finY = finY*percentFinal/100;
	
	//Aplicar valores finales a canvas
	var canvasDOM = document.getElementById('c');
	canvasDOM.width = finX;
	canvasDOM.height = finY;
}

function getCanvasWidth(){
	return finX;
}

function getCanvasHeight(){ 
	return finY;
}

function getObjectWidthFromPercentX(percent){
	return getCanvasWidth()*percent/100;
}

function getObjectWidthFromPercentY(percent){
	return getCanvasHeight()*percent/100;
}

function getObjectScaleFromPercentX(object, percentFinalWidth){
	var localFinalWidth = getCanvasWidth()*percentFinalWidth/100;
	var localIniWidth = object.getWidth();
	var percentToScale = localFinalWidth*100/localIniWidth;
	var numberToScale = (percentToScale/100);
	return numberToScale;
}

function getObjectScaleFromPercentY(object, percentFinalHeight){
	var localFinalHeight = getCanvasHeight()*percentFinalHeight/100;
	var localIniHeight = object.getHeight();
	var percentToScale = localFinalHeight*100/localIniHeight;
	var numberToScale = (percentToScale/100);
	return numberToScale;
}

function getPosCanvasCenterX(){
	return getCanvasWidth()/2;
}

function getPosCanvasCenterY(){
	return getCanvasHeight()/2;
}

function getPosObjectCenterX(object){
	return getPosCanvasCenterX() - (object.getWidth()/2);
}

function getPosObjectCenterY(object){
	return getPosCanvasCenterY() - (object.getHeight()/2);
}

function getPosObjectFromPercentX(percent){
	return getCanvasWidth()*percent/100;
}

function getPosObjectFromPercentY(percent){
	return getCanvasHeight()*percent/100;
}




/////////////////////
/////UTIL VARIOS/////
/////////////////////


function guid() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000)
		  .toString(16)
		  .substring(1);
		}
	return s4() + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

function openLink(url){
	var win = window.open(url, '_blank');
	win.focus();
}




//////////////////////////
/////FABRIC JS CUSTOM/////
//////////////////////////

fabric.Scene = fabric.util.createClass(fabric.Object, {
	initialize: function() {
		this.id = guid();
		this.objects = [];
	},
	
	/**
	 * Add Object on Scene
	 * @param object
	 * @returns {fabric.Scene}
	 */
	addObject : function(object) {
		this.objects.push(object);
		canvas.add(object);
		return this;
	},
	
	renderAll : function(){
		
		
		return this;
	}
});



fabric.ButtonRect = fabric.util.createClass(fabric.Rect, {
	initialize: function() {
		options={
			selectable:true,
			hasControls:false,
			hasBorders:false,
			lockRotation:true,
			lockScalingX:true,
			lockScalingY:true,
			lockMovementX:true,
			lockMovementY:true
		}
		this.callSuper('initialize', options);
		this.on('selected', function(){canvas.deactivateAll().renderAll()});
	},
	
	addEvent: function(functionEvent){
		this.on('selected', functionEvent);
	}
});



fabric.ButtonCircle = fabric.util.createClass(fabric.Circle, {
	initialize: function() {
		options={
			selectable:true,
			hasControls:false,
			hasBorders:false,
			lockRotation:true,
			lockScalingX:true,
			lockScalingY:true,
			lockMovementX:true,
			lockMovementY:true
		}
		this.callSuper('initialize', options);
		this.on('selected', function(){canvas.deactivateAll().renderAll()});
	},
	
	addEvent: function(functionEvent){
		this.on('selected', functionEvent);
	}
});
