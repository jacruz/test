var canvas;
initialize();
scene1Container();

/////////////////////////////
///////AJUSTE CANVAS/////////
/////////////////////////////
function initialize(){
	resizeCanvas();
	canvas = new fabric.Canvas('c');
	canvas.backgroundColor = 'rgba(0,150,0,0.9)';
}


////////////////////////
///////ESCENA 1/////////
////////////////////////
function scene1Container(){
	alert(x + " - " + y + "       " + getCanvasWidth()+" - "+getCanvasHeight());
	var scene1 = new fabric.Scene(canvas);


	//Creaci�n de objetos
	var text1Text = "Tittle tittle tittle";
	var text1 = new fabric.Text(text1Text);
	//parametrizar objetos
	text1.set({fontFamily: 'Arial'});
	text1.setScaleX(getObjectScaleFromPercentX(text1,50));	//Escalar relativo al tama�o del canvas
	text1.setScaleY(getObjectScaleFromPercentY(text1,15));	//Escalar relativo al tama�o del canvas
	text1.set({left:(getPosObjectCenterX(text1))});			//centrado en X
	text1.set({top:getPosObjectFromPercentY(9.0)});			//pos relativa al tama�o del canvas
	text1.set({selectable:false});							//evita modificaciones
	//Agregar objetos a escena
	scene1.addObject(text1);


	//Creaci�n de objetos
	var buttonRect1 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect1.set({width:(getObjectWidthFromPercentX(36))});	//tama�o relativo al tama�o del canvas
	buttonRect1.set({height:(getObjectWidthFromPercentY(63))});	//tama�o relativo al tama�o del canvas
	buttonRect1.set({left:getPosObjectFromPercentX(23.5)});		//pos relativa al tama�o del canvas
	buttonRect1.set({top:getPosObjectFromPercentY(30.0)});		//pos relativa al tama�o del canvas
	buttonRect1.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect1);


	//Creaci�n de objetos
	var buttonRect2 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect2.set({width:(getObjectWidthFromPercentX(16))});	//tama�o relativo al tama�o del canvas
	buttonRect2.set({height:(getObjectWidthFromPercentY(30))});	//tama�o relativo al tama�o del canvas
	buttonRect2.set({left:getPosObjectFromPercentX(61)});		//pos relativa al tama�o del canvas
	buttonRect2.set({top:getPosObjectFromPercentY(30.0)});		//pos relativa al tama�o del canvas
	buttonRect2.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect2);


	//Creaci�n de objetos
	var buttonRect3 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect3.set({width:(getObjectWidthFromPercentX(16))});	//tama�o relativo al tama�o del canvas
	buttonRect3.set({height:(getObjectWidthFromPercentY(30))});	//tama�o relativo al tama�o del canvas
	buttonRect3.set({left:getPosObjectFromPercentX(61)});		//pos relativa al tama�o del canvas
	buttonRect3.set({top:getPosObjectFromPercentY(63.0)});		//pos relativa al tama�o del canvas
	buttonRect3.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect3);


	//Creaci�n de objetos
	var buttonRect4 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect4.set({width:(getObjectWidthFromPercentX(9))});	//tama�o relativo al tama�o del canvas
	buttonRect4.set({height:(getObjectWidthFromPercentY(16))});	//tama�o relativo al tama�o del canvas
	buttonRect4.set({left:getPosObjectFromPercentX(88)});		//pos relativa al tama�o del canvas
	buttonRect4.set({top:getPosObjectFromPercentY(6.0)});		//pos relativa al tama�o del canvas
	buttonRect4.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect4);

	//Creaci�n de objetos
	var buttonRect5 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect5.set({width:(getObjectWidthFromPercentX(9))});	//tama�o relativo al tama�o del canvas
	buttonRect5.set({height:(getObjectWidthFromPercentY(16))});	//tama�o relativo al tama�o del canvas
	buttonRect5.set({left:getPosObjectFromPercentX(88)});		//pos relativa al tama�o del canvas
	buttonRect5.set({top:getPosObjectFromPercentY(25.0)});		//pos relativa al tama�o del canvas
	buttonRect5.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect5);


	//Creaci�n de objetos
	var buttonRect6 = new fabric.ButtonRect();
	//parametrizar objetos
	buttonRect6.set({width:(getObjectWidthFromPercentX(9))});	//tama�o relativo al tama�o del canvas
	buttonRect6.set({height:(getObjectWidthFromPercentY(16))});	//tama�o relativo al tama�o del canvas
	buttonRect6.set({left:getPosObjectFromPercentX(88)});		//pos relativa al tama�o del canvas
	buttonRect6.set({top:getPosObjectFromPercentY(80.0)});		//pos relativa al tama�o del canvas
	buttonRect6.set('fill', 'white');							//relleno color
	//Agregar objetos a escena
	scene1.addObject(buttonRect6);


	//Creaci�n de objetos
	var image1;
	fabric.Image.fromURL('img/unidad.jpg', function(oImg) {
		image1 = oImg;
		//parametrizar objetos
		image1.set({width:(getObjectWidthFromPercentX(10))});	//tama�o relativo al tama�o del canvas
		image1.set({height:(getObjectWidthFromPercentY(9))});	//tama�o relativo al tama�o del canvas
		image1.set({left:getPosObjectFromPercentX(3)});		//pos relativa al tama�o del canvas
		image1.set({top:getPosObjectFromPercentY(88.0)});		//pos relativa al tama�o del canvas
		image1.set({selectable:false});							//evita modificaciones
		//Agregar objetos a escena
		scene1.addObject(image1);
		canvas.renderAll();
	});



	//Eventos de objetos
	buttonRect6.addEvent(function() {
		openLink("http://google.com");
		canvas.deactivateAll().renderAll();
	});


}